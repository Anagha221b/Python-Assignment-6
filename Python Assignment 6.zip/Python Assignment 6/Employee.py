class Employee:
    def __init__(self,name,salary):
        self.name=name
        self.salary=salary
    #function to get name of the employee    
    def get_name(self):
        return self.name
    #function to get salary of the employee  
    def get_salary(self):
        return self.salary