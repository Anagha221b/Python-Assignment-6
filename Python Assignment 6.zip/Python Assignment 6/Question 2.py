#importing employee class from Employee module
from Employee import Employee

#object for Employee 1
emp=Employee("Rohan",35000)
# object for Employee 2
emp1=Employee("Virat", 43000)

#for Employee 1
print("Employee 1 details->")
print(f"  Employee name: {emp.get_name()}")
print(f"  Employee Salary: {emp.get_salary()}")

#for Employee 2
print("Employee 2 details->")
print(f"  Employee name: {emp1.get_name()}")
print(f"  Employee name: {emp1.get_salary()}")