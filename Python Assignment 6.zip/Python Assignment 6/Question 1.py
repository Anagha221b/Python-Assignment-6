#This program will manage a university's course catalog
#base class
class Course: 
    def __init__(self, course_code, course_name, credit_hours):
        self.course_code = course_code
        self.course_name = course_name
        self.credit_hours = credit_hours

#subclass
class CoreCourse(Course):
    def __init__(self, course_code, course_name, credit_hours, required_for_major):
        super().__init__(course_code, course_name, credit_hours)
        self.required_for_major = required_for_major

# subclass
class ElectiveCourse(Course):
    def __init__(self, course_code, course_name, credit_hours, elective_type):
        super().__init__(course_code, course_name, credit_hours)
        self.elective_type = elective_type

#object created for Core Course
core_course=CoreCourse("CS101", "Introduction to Computer Science", 3, True)

#object created for Elective Course
elective_course=ElectiveCourse("ENGL102", "Creative Writing", 2, "liberal arts")

#for Core course
print("Core Course-> ")
print(f"  Course code: {core_course.course_code}")
print(f"  Course name: {core_course.course_name}")
print(f"  Credit hours: {core_course.credit_hours}")
print(f"  Required for major: {core_course.required_for_major}")

#for Elective course
print("Elective Course-> ")
print(f"  Course code: {elective_course.course_code}")
print(f"  Course name: {elective_course.course_name}")
print(f"  Credit hours: {elective_course.credit_hours}")
print(f"  Elective type: {elective_course.elective_type}")